1. man, is short for manual, easy one.
1. pwd, print working direction.
1. mkdir, make a new direction.
1. rmdir, remove a existed direction.
1. cd, change diretion.
1. ls, list.
1. find, this is what I want to looking in, but it is  not a effcient one.
to find files by filter
1. mv, move file or direction to somewhere.
1. more, to have a brief looking at files.
1. make, compile command for Makefile.

comment like
tar -cvvf targetFile.tar sourceFile
and
gzip targetFile.tar
I would like to use a lazy one
tar -czvf targetFile.tar.gz
Also, for
gunzip sourceFile.tar.gz
tar -xovf sourceFile.tar
I would like to use
tar -xzvf sourceFile.tar.gz

And I don't like .exe for excutable file, because we all working on Linux or mac, right?
